TayloredTV v0.6 skin: clean transparent logo. Install the companion catalogue v0.5. Back button requires separate Kodi keymap in userdata/keymaps.
